$env:PATH += ";C:\Xilinx\Vivado\2020.2\bin;C:\Xilinx\Vivado\2020.2\lib\win64.o;"
$env:XILINX_VIVADO="C:\Xilinx\Vivado\2020.2"